
# Aroma de Pizza Lounge 24h - Página de Reservas

Este é o código-fonte da landing page para o Lounge VIP do evento Aroma de Pizza 24h em São Pedro de Caém 2025.

## Funcionalidades
- Informações sobre o evento
- Botão de reserva via WhatsApp
- Vídeos da última edição via Instagram Reels embutidos

## Como usar
1. Suba os arquivos no GitHub Pages ou qualquer serviço de hospedagem web estática.
2. Acesse pelo navegador para visualizar a página.

## Contato
- WhatsApp para reservas: (71) 99268-6345
- Instagram: @aromadepizza

© 2025 Aroma de Pizza
